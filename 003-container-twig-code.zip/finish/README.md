Micro-Symfony Framework
=================================

This repository holds the screencast code, script and all the AJAX
you can eat for the WIP "Micro-Symfony Framework" course from KnpUniversity.

Subscribe for update: [KnpUniversity: Micro-Symfony Framework](http://knpuniversity.com/screencast/micro-symfony)

Collaboration
-------------

As we start writing the content for this tutorial, we invite you to read
through it, try things out, and offer improvements, either as issues on this
repository or as pull requests. REST is hard, so the more smart minds we
can have on it, the better it will be for everyone.

Cheers!
